"""
common.py - shared helpers used by all scripts.

1. load_template(): parses CloudFormation / SAM files (YAML or JSON), including
   short-form tags like !Ref and !GetAtt that normal YAML parsers choke on.
2. analyze_template(): our own rule engine. It looks for IAM and API
   misconfigurations, including CROSS-RESOURCE ones (a publicly reachable
   function that also has a powerful role). This cross-resource check is the
   novel part of the paper.
"""
import fnmatch
import json
import re
from pathlib import Path

import yaml

# ----------------------------------------------------------------------------
# 1. Loading templates
# ----------------------------------------------------------------------------


class CFNLoader(yaml.SafeLoader):
    pass


def _tag(loader, suffix, node):
    """Turn !Ref x  ->  {"Ref": "x"},  !GetAtt a.b -> {"Fn::GetAtt": ["a","b"]} ..."""
    if isinstance(node, yaml.ScalarNode):
        value = loader.construct_scalar(node)
    elif isinstance(node, yaml.SequenceNode):
        value = loader.construct_sequence(node, deep=True)
    else:
        value = loader.construct_mapping(node, deep=True)
    if suffix == "Ref":
        return {"Ref": value}
    if suffix == "GetAtt" and isinstance(value, str):
        value = value.split(".", 1)
    name = suffix if suffix == "Condition" else "Fn::" + suffix
    return {name: value}


CFNLoader.add_multi_constructor("!", _tag)


def load_template(path):
    """Return the template as a dict, or None if it cannot be parsed."""
    try:
        text = Path(path).read_text(encoding="utf-8", errors="ignore")
        if str(path).lower().endswith(".json"):
            data = json.loads(text)
        else:
            data = yaml.load(text, Loader=CFNLoader)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def is_cfn_template(data):
    """True if it looks like a real CloudFormation/SAM template."""
    if not isinstance(data, dict):
        return False
    res = data.get("Resources")
    if not isinstance(res, dict) or not res:
        return False
    # every resource should be a dict with a Type
    ok = [isinstance(v, dict) and "Type" in v for v in res.values()]
    return sum(ok) >= 1 and (
        "AWSTemplateFormatVersion" in data or "Transform" in data or sum(ok) == len(ok)
    )


# ----------------------------------------------------------------------------
# 2. Rule engine
# ----------------------------------------------------------------------------

# Actions that are routinely OK on Resource "*" (logging, tracing, VPC ENIs ...)
SAFE_STAR_PREFIXES = (
    "logs:", "xray:", "cloudwatch:putmetricdata", "ec2:createnetworkinterface",
    "ec2:describenetworkinterfaces", "ec2:deletenetworkinterface",
    "ec2:describe", "sts:getcalleridentity",
)

# Actions known to allow privilege escalation (Rhino Security Labs list, abridged)
PRIVESC_ACTIONS = [
    "iam:passrole", "iam:createpolicyversion", "iam:setdefaultpolicyversion",
    "iam:attachuserpolicy", "iam:attachgrouppolicy", "iam:attachrolepolicy",
    "iam:putuserpolicy", "iam:putgrouppolicy", "iam:putrolepolicy",
    "iam:addusertogroup", "iam:updateassumerolepolicy", "iam:createaccesskey",
    "iam:createloginprofile", "iam:updateloginprofile",
    "lambda:updatefunctioncode", "lambda:createfunction",
    "lambda:updatefunctionconfiguration", "sts:assumerole",
    "cloudformation:createstack", "glue:createdevendpoint",
    "iam:putrolepermissionsboundary", "iam:putuserpermissionsboundary",
]

ADMIN_MANAGED = ("administratoraccess", "poweruseraccess", "iamfullaccess")


def _as_list(x):
    if x is None:
        return []
    return x if isinstance(x, list) else [x]


def _is_star(x):
    """True for "*" (also handles {"Fn::Sub": "*"} style)."""
    if isinstance(x, str):
        return x.strip() == "*"
    return False


def _statements(doc):
    """Yield statement dicts from a policy document (dict or list)."""
    if isinstance(doc, dict):
        st = doc.get("Statement")
        for s in _as_list(st):
            if isinstance(s, dict):
                yield s


def _matches_action(pattern, action):
    return fnmatch.fnmatchcase(action.lower(), pattern.lower())


def check_statement(stmt):
    """Return a set of finding codes for ONE IAM policy statement."""
    found = set()
    if str(stmt.get("Effect", "Allow")).lower() != "allow":
        return found
    actions = [a for a in _as_list(stmt.get("Action")) if isinstance(a, str)]
    resources = _as_list(stmt.get("Resource"))
    star_res = any(_is_star(r) for r in resources)
    has_condition = bool(stmt.get("Condition"))

    if "NotAction" in stmt:
        found.add("IAM_ALLOW_NOTACTION")
    if any(_is_star(a) for a in actions):
        found.add("IAM_WILDCARD_ACTION_ALL")
        if star_res:
            found.add("IAM_FULL_ADMIN")
    elif any(a.endswith(":*") for a in actions):
        found.add("IAM_WILDCARD_ACTION_SERVICE")
    if star_res and actions:
        risky = [a for a in actions
                 if not a.lower().startswith(SAFE_STAR_PREFIXES)]
        if risky:
            found.add("IAM_WILDCARD_RESOURCE")
    # privilege-escalation actions (direct or via wildcard like iam:*)
    for a in actions:
        for p in PRIVESC_ACTIONS:
            if _matches_action(a, p) or a.lower() == p:
                if not has_condition or star_res:
                    found.add("IAM_PRIVESC_ACTION")
    return found


def _policy_docs_from_policies(policies):
    """SAM 'Policies' / CFN role 'Policies' -> (list of docs, list of managed names)."""
    docs, managed = [], []
    for p in _as_list(policies):
        if isinstance(p, str):
            managed.append(p)
        elif isinstance(p, dict):
            if "Statement" in p:                          # SAM inline policy
                docs.append(p)
            elif isinstance(p.get("PolicyDocument"), dict):  # CFN inline policy
                docs.append(p["PolicyDocument"])
            elif "Fn::Sub" in p or "Ref" in p:
                managed.append(json.dumps(p))
            # else: SAM policy template (e.g. S3ReadPolicy) -> scoped, ignore
    return docs, managed


def _managed_findings(names):
    found = set()
    for n in names:
        low = str(n).lower()
        if any(a in low for a in ADMIN_MANAGED):
            found.add("IAM_MANAGED_ADMIN")
        elif "fullaccess" in low:
            found.add("IAM_MANAGED_FULLACCESS")
    return found


def _ref_target(x):
    """Resolve {"Ref": "X"} or {"Fn::GetAtt": ["X","Arn"]} to logical id X."""
    if isinstance(x, dict):
        if "Ref" in x and isinstance(x["Ref"], str):
            return x["Ref"]
        ga = x.get("Fn::GetAtt")
        if isinstance(ga, list) and ga and isinstance(ga[0], str):
            return ga[0]
    return None


def _role_findings(role_res):
    props = role_res.get("Properties", {}) or {}
    found = set()
    docs, managed = _policy_docs_from_policies(props.get("Policies"))
    managed += [m for m in _as_list(props.get("ManagedPolicyArns")) if isinstance(m, str)]
    for d in docs:
        for s in _statements(d):
            found |= check_statement(s)
    found |= _managed_findings(managed)
    # trust policy open to everyone
    trust = props.get("AssumeRolePolicyDocument")
    for s in _statements(trust):
        if str(s.get("Effect", "Allow")).lower() == "allow" and not s.get("Condition"):
            pr = s.get("Principal")
            if _is_star(pr) or (isinstance(pr, dict) and any(_is_star(v) for v in _as_list(pr.get("AWS")))):
                found.add("IAM_TRUST_WILDCARD_PRINCIPAL")
    return found


PRIV_CODES = {"IAM_FULL_ADMIN", "IAM_WILDCARD_ACTION_ALL", "IAM_WILDCARD_ACTION_SERVICE",
              "IAM_PRIVESC_ACTION", "IAM_MANAGED_ADMIN"}


def analyze_template(data):
    """
    Return {"findings": {code: [resource ids]}, "n_resources": int}
    Codes starting IAM_ = identity/permission problems
    Codes starting API_ = API exposure problems
    Codes starting CROSS_ = IAM + API combined (the paper's novelty)
    """
    findings = {}

    def add(code, rid):
        findings.setdefault(code, [])
        if rid not in findings[code]:
            findings[code].append(rid)

    resources = data.get("Resources", {}) or {}
    globals_ = data.get("Globals", {}) or {}
    g_api_auth = ((globals_.get("Api") or {}).get("Auth") or {})
    g_http_auth = ((globals_.get("HttpApi") or {}).get("Auth") or {})

    # --- index of explicit APIs and their default authorizers -----------------
    api_has_default_auth = {}
    for rid, r in resources.items():
        if not isinstance(r, dict):
            continue
        t, props = r.get("Type"), (r.get("Properties") or {})
        if t in ("AWS::Serverless::Api", "AWS::Serverless::HttpApi"):
            auth = props.get("Auth") or {}
            api_has_default_auth[rid] = bool(
                isinstance(auth, dict) and (auth.get("DefaultAuthorizer") or auth.get("ApiKeyRequired"))
            )
            cors = props.get("CorsConfiguration") or props.get("Cors")
            if cors and "*" in json.dumps(cors) and "AllowOrigin" in json.dumps(cors) + "AllowOrigins":
                add("API_CORS_WILDCARD", rid)

    # --- IAM roles --------------------------------------------------------------
    role_codes = {}
    for rid, r in resources.items():
        if isinstance(r, dict) and r.get("Type") == "AWS::IAM::Role":
            codes = _role_findings(r)
            role_codes[rid] = codes
            for c in codes:
                add(c, rid)
        elif isinstance(r, dict) and r.get("Type") in (
                "AWS::IAM::Policy", "AWS::IAM::ManagedPolicy"):
            for s in _statements((r.get("Properties") or {}).get("PolicyDocument")):
                for c in check_statement(s):
                    add(c, rid)

    # --- Functions: privilege + public exposure --------------------------------
    for rid, r in resources.items():
        if not isinstance(r, dict):
            continue
        t, props = r.get("Type"), (r.get("Properties") or {})
        if t not in ("AWS::Serverless::Function", "AWS::Lambda::Function"):
            continue

        # privilege of the function
        priv = set()
        docs, managed = _policy_docs_from_policies(props.get("Policies"))
        managed += [m for m in _as_list(props.get("ManagedPolicyArns")) if isinstance(m, str)]
        for d in docs:
            for s in _statements(d):
                priv |= check_statement(s)
        priv |= _managed_findings(managed)
        role_id = _ref_target(props.get("Role"))
        if role_id in role_codes:
            priv |= role_codes[role_id]
        for c in priv:
            if t == "AWS::Serverless::Function":
                add(c, rid)

        # public exposure
        public = False
        events = props.get("Events") or {}
        if isinstance(events, dict):
            for ename, ev in events.items():
                if not isinstance(ev, dict):
                    continue
                et, ep = ev.get("Type"), (ev.get("Properties") or {})
                if et in ("Api", "HttpApi"):
                    auth = ep.get("Auth") or {}
                    authorizer = auth.get("Authorizer") if isinstance(auth, dict) else None
                    api_id = _ref_target(ep.get("RestApiId") or ep.get("ApiId"))
                    default_ok = False
                    if api_id and api_id in api_has_default_auth:
                        default_ok = api_has_default_auth[api_id]
                    elif not api_id:
                        g = g_api_auth if et == "Api" else g_http_auth
                        default_ok = bool(g.get("DefaultAuthorizer") or g.get("ApiKeyRequired"))
                    explicit_ok = authorizer is not None and str(authorizer).upper() != "NONE"
                    if isinstance(auth, dict) and auth.get("ApiKeyRequired"):
                        explicit_ok = True
                    explicit_none = authorizer is not None and str(authorizer).upper() == "NONE"
                    no_auth = explicit_none or not (explicit_ok or default_ok)
                    if no_auth:
                        add("API_NO_AUTHORIZER", rid)
                        public = True
        fu = props.get("FunctionUrlConfig")
        if isinstance(fu, dict) and str(fu.get("AuthType", "")).upper() == "NONE":
            add("API_FUNCTION_URL_NO_AUTH", rid)
            public = True

        if public and (priv & PRIV_CODES):
            add("CROSS_PUBLIC_PRIVILEGED_FUNCTION", rid)

    # --- Plain CloudFormation API Gateway --------------------------------------
    for rid, r in resources.items():
        if not isinstance(r, dict):
            continue
        t, props = r.get("Type"), (r.get("Properties") or {})
        if t == "AWS::ApiGateway::Method":
            if str(props.get("AuthorizationType", "NONE")).upper() == "NONE" \
                    and str(props.get("HttpMethod", "")).upper() != "OPTIONS" \
                    and not props.get("ApiKeyRequired"):
                add("API_NO_AUTHORIZER", rid)
        elif t == "AWS::ApiGatewayV2::Route":
            if str(props.get("AuthorizationType", "NONE")).upper() == "NONE":
                add("API_NO_AUTHORIZER", rid)
        elif t == "AWS::Lambda::Url":
            if str(props.get("AuthType", "")).upper() == "NONE":
                add("API_FUNCTION_URL_NO_AUTH", rid)
        elif t == "AWS::Lambda::Permission":
            if _is_star(props.get("Principal")) and not props.get("SourceArn") \
                    and not props.get("SourceAccount"):
                add("API_LAMBDA_PERMISSION_OPEN", rid)

    return {"findings": findings, "n_resources": len(resources)}


def category_of(code):
    return code.split("_", 1)[0]  # IAM / API / CROSS
