"""
2_label.py - label every collected template with two independent "oracles":

  Oracle A = our own rule engine (common.py): IAM + API + CROSS-resource rules
  Oracle B = Checkov (open-source scanner, run as a command-line program)

USAGE
    python 2_label.py                 # runs both
    python 2_label.py --skip-checkov  # only our rules (fast, for testing)

OUTPUT
    corpus/labels.csv       one row per file with both oracles' findings and labels
    corpus/findings_long.csv  one row per finding (handy for charts in the paper)
"""
import argparse
import json
import subprocess
import tempfile
from collections import Counter
from pathlib import Path

import pandas as pd

from common import load_template, analyze_template, category_of

OUT = Path("corpus")
RAW = OUT / "raw"


# --- keyword mapping from Checkov check names to our scope ------------------
def checkov_category(check_name):
    n = check_name.lower()
    if any(k in n for k in ("api gateway", "apigateway", "api ", "authoriz", "cors",
                            "lambda function url", "lambda permission")):
        return "API"
    if any(k in n for k in ("iam", "policy", "policies", "privilege", "admin",
                            "wildcard", "assume", "role", "credentials exposure",
                            "permissions management", "write access")):
        return "IAM"
    return "OTHER"       # encryption, logging, etc. -> out of scope for this paper


def run_checkov(files, batch_size=150, timeout=900):
    """Run checkov on batches of files. Returns {file_id: [ {id,name,cat}, ... ]}, scanned_ids"""
    findings, scanned = {}, set()
    files = list(files)
    for i in range(0, len(files), batch_size):
        batch = files[i:i + batch_size]
        cmd = ["checkov", "--framework", "cloudformation", "-o", "json",
               "--quiet", "--compact", "--skip-download"]
        for f in batch:
            cmd += ["-f", str(f)]
        print(f"  checkov batch {i // batch_size + 1}/{(len(files) - 1) // batch_size + 1} ...", flush=True)
        try:
            p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            print("   (batch timed out, skipped)")
            continue
        out = p.stdout.strip()
        if not out:
            continue
        try:
            js = json.loads(out)
        except json.JSONDecodeError:
            # checkov sometimes prints extra text before the JSON
            start = out.find("{") if out.find("{") != -1 else out.find("[")
            try:
                js = json.loads(out[start:])
            except Exception:
                print("   (could not parse checkov output for this batch)")
                continue
        reports = js if isinstance(js, list) else [js]
        for rep in reports:
            res = rep.get("results", {})
            for kind in ("passed_checks", "failed_checks"):
                for c in res.get(kind, []):
                    fid = Path(c["file_path"]).stem
                    scanned.add(fid)
                    if kind == "failed_checks":
                        findings.setdefault(fid, []).append({
                            "id": c["check_id"], "name": c["check_name"],
                            "cat": checkov_category(c["check_name"])})
    return findings, scanned


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-checkov", action="store_true")
    args = ap.parse_args()

    meta = pd.read_csv(OUT / "metadata.csv")
    files = [RAW / f"{r.file_id}.{r.ext}" for r in meta.itertuples()]
    print(f"{len(files)} files to label")

    # ---------- Oracle A: our rules ----------
    rows, long_rows = [], []
    for r in meta.itertuples():
        path = RAW / f"{r.file_id}.{r.ext}"
        data = load_template(path)
        if data is None:
            continue
        res = analyze_template(data)
        codes = res["findings"]
        cats = sorted({category_of(c) for c in codes})
        rows.append({
            "file_id": r.file_id,
            "n_resources": res["n_resources"],
            "custom_codes": ";".join(sorted(codes)),
            "custom_cats": ";".join(cats),
            "label_custom": int(len(codes) > 0),
        })
        for c, rids in codes.items():
            long_rows.append({"file_id": r.file_id, "oracle": "custom", "code": c,
                              "category": category_of(c), "resources": ";".join(rids)})
    df = pd.DataFrame(rows)

    # ---------- Oracle B: Checkov ----------
    if args.skip_checkov:
        df["checkov_scanned"] = False
        df["checkov_ids"] = ""
        df["label_checkov"] = pd.NA
    else:
        print("Running Checkov (this can take 10-60 minutes for thousands of files)...")
        ck, scanned = run_checkov(files)
        df["checkov_scanned"] = df.file_id.isin(scanned)
        ids, labs = [], []
        for fid, sc in zip(df.file_id, df.checkov_scanned):
            fl = [f for f in ck.get(fid, []) if f["cat"] in ("IAM", "API")]
            ids.append(";".join(sorted({f["id"] for f in fl})))
            labs.append((1 if fl else 0) if sc else pd.NA)
            for f in fl:
                long_rows.append({"file_id": fid, "oracle": "checkov", "code": f["id"],
                                  "category": f["cat"], "resources": f["name"]})
        df["checkov_ids"] = ids
        df["label_checkov"] = labs

    # ---------- merge ----------
    def consensus(row):
        if pd.isna(row.label_checkov):
            return "custom_only"
        if row.label_custom == row.label_checkov:
            return "agree_pos" if row.label_custom == 1 else "agree_neg"
        return "disagree"

    df["agreement"] = df.apply(consensus, axis=1)
    df = df.merge(meta[["file_id", "repo", "path", "stars", "license", "near_dup_signature"]],
                  on="file_id", how="left")
    df.to_csv(OUT / "labels.csv", index=False)
    pd.DataFrame(long_rows).to_csv(OUT / "findings_long.csv", index=False)

    print("\n=== SUMMARY (copy these numbers into your paper) ===")
    print("files labeled:", len(df))
    print("custom rules flagged:", int(df.label_custom.sum()),
          f"({df.label_custom.mean():.1%})")
    if not args.skip_checkov:
        sc = df[df.checkov_scanned]
        print("checkov scanned:", len(sc), "| flagged:", int(sc.label_checkov.astype(int).sum()))
        print(df.agreement.value_counts().to_string())
    cnt = Counter(c for s in df.custom_codes for c in s.split(";") if c)
    print("\nfindings per rule (custom):")
    for k, v in cnt.most_common():
        print(f"  {k:40s} {v}")
    print(f"\nSaved {OUT/'labels.csv'}")


if __name__ == "__main__":
    main()
