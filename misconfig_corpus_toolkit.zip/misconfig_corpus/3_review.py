"""
3_review.py - manual review step (creates the GOLD test set).

STEP A - make the annotation sheets:
    python 3_review.py sample --n 200
  -> review/annotator_A.csv, review/annotator_B.csv   (identical blank sheets)
  -> review/answer_key_DO_NOT_OPEN.csv                 (what the tools said)

  Each annotator opens corpus/raw/<file_id>.<ext> and fills in:
      is_misconfigured : 1 or 0   (is there a real IAM or API security problem?)
      category         : IAM / API / BOTH / NONE
      notes            : optional
  Annotators must work independently, WITHOUT looking at the answer key.

STEP B - after both sheets are filled in:
    python 3_review.py kappa
  -> prints Cohen's kappa, saves review/disagreements.csv
  -> fill the 'final_label' column in disagreements.csv (discuss and decide), then:

STEP C:
    python 3_review.py gold
  -> review/gold.csv   (final human labels)  + how good Checkov / custom rules are vs. gold
"""
import argparse
from pathlib import Path

import pandas as pd

OUT = Path("corpus")
REV = Path("review")


def sample(n, seed=42):
    lab = pd.read_csv(OUT / "labels.csv")
    meta = pd.read_csv(OUT / "metadata.csv")[["file_id", "ext"]]
    lab = lab.merge(meta, on="file_id")
    # keep it readable: skip giant files, and only one file per near-duplicate group
    lab = lab[lab.n_resources.between(1, 40)]
    lab = lab.drop_duplicates("near_dup_signature")
    pos = lab[lab.label_custom == 1]
    neg = lab[lab.label_custom == 0]
    # stratify: 50% flagged by our rules, 50% not flagged (so we can measure misses too)
    k = n // 2
    s = pd.concat([pos.sample(min(k, len(pos)), random_state=seed),
                   neg.sample(min(n - k, len(neg)), random_state=seed)])
    s = s.sample(frac=1, random_state=seed)  # shuffle
    REV.mkdir(exist_ok=True)
    blank = pd.DataFrame({
        "file_id": s.file_id, "open_this_file": [f"corpus/raw/{a}.{b}" for a, b in zip(s.file_id, s.ext)],
        "is_misconfigured": "", "category": "", "notes": ""})
    blank.to_csv(REV / "annotator_A.csv", index=False)
    blank.to_csv(REV / "annotator_B.csv", index=False)
    s[["file_id", "custom_codes", "checkov_ids", "label_custom", "label_checkov"]] \
        .to_csv(REV / "answer_key_DO_NOT_OPEN.csv", index=False)
    print(f"Created sheets with {len(s)} files in {REV}/")


def cohen_kappa(a, b):
    n = len(a)
    po = sum(x == y for x, y in zip(a, b)) / n
    pe = sum((sum(1 for x in a if x == c) / n) * (sum(1 for y in b if y == c) / n)
             for c in set(a) | set(b))
    return (po - pe) / (1 - pe) if pe != 1 else 1.0


def kappa():
    A = pd.read_csv(REV / "annotator_A.csv")
    B = pd.read_csv(REV / "annotator_B.csv")
    m = A.merge(B, on="file_id", suffixes=("_A", "_B"))
    m = m.dropna(subset=["is_misconfigured_A", "is_misconfigured_B"])
    k = cohen_kappa(m.is_misconfigured_A.astype(int).tolist(),
                    m.is_misconfigured_B.astype(int).tolist())
    print(f"Files annotated by both: {len(m)}")
    print(f"Cohen's kappa = {k:.3f}   (>0.80 almost perfect, 0.61-0.80 substantial)")
    d = m[m.is_misconfigured_A.astype(int) != m.is_misconfigured_B.astype(int)].copy()
    d["final_label"] = ""
    d.to_csv(REV / "disagreements.csv", index=False)
    print(f"{len(d)} disagreements saved to {REV/'disagreements.csv'} - resolve them by discussion,")
    print("write 1 or 0 in the 'final_label' column, then run:  python 3_review.py gold")


def gold():
    A = pd.read_csv(REV / "annotator_A.csv")
    B = pd.read_csv(REV / "annotator_B.csv")
    m = A.merge(B, on="file_id", suffixes=("_A", "_B")).dropna(
        subset=["is_misconfigured_A", "is_misconfigured_B"])
    m["gold"] = m.is_misconfigured_A.astype(int)
    agree = m.is_misconfigured_A.astype(int) == m.is_misconfigured_B.astype(int)
    m.loc[~agree, "gold"] = pd.NA
    dpath = REV / "disagreements.csv"
    if dpath.exists():
        d = pd.read_csv(dpath).dropna(subset=["final_label"])
        fix = dict(zip(d.file_id, d.final_label.astype(int)))
        m["gold"] = [fix.get(f, g) for f, g in zip(m.file_id, m.gold)]
    m = m.dropna(subset=["gold"])
    m["gold"] = m.gold.astype(int)
    m[["file_id", "gold", "category_A", "category_B", "notes_A", "notes_B"]].to_csv(
        REV / "gold.csv", index=False)
    print(f"GOLD set: {len(m)} files, {int(m.gold.sum())} misconfigured "
          f"({m.gold.mean():.1%})")

    lab = pd.read_csv(OUT / "labels.csv")
    j = m.merge(lab, on="file_id")
    print("\nHow good are the tools themselves, measured against human gold labels?")
    for name, col in (("Custom rules", "label_custom"), ("Checkov (IAM/API checks)", "label_checkov")):
        jj = j.dropna(subset=[col])
        if jj.empty:
            continue
        y, p = jj.gold, jj[col].astype(int)
        tp = int(((y == 1) & (p == 1)).sum()); fp = int(((y == 0) & (p == 1)).sum())
        fn = int(((y == 1) & (p == 0)).sum())
        prec = tp / (tp + fp) if tp + fp else 0
        rec = tp / (tp + fn) if tp + fn else 0
        f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0
        print(f"  {name:28s} precision={prec:.2f} recall={rec:.2f} F1={f1:.2f}  (n={len(jj)})")
    print("\nSaved review/gold.csv")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["sample", "kappa", "gold"])
    ap.add_argument("--n", type=int, default=200)
    a = ap.parse_args()
    {"sample": lambda: sample(a.n), "kappa": kappa, "gold": gold}[a.cmd]()
