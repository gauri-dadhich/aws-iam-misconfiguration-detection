"""
1_collect.py - download real-world CloudFormation / SAM templates from GitHub.

USAGE
    python 1_collect.py --quick          # small test run (~10 minutes)
    python 1_collect.py                  # full run (1-3 hours, can be stopped and resumed)

Needs an environment variable GITHUB_TOKEN (see README.md, Step 3).

OUTPUT
    corpus/raw/<id>.<ext>      the template files
    corpus/metadata.csv        one row per file (repo, path, commit, license, stars, ...)
    corpus/state.json          progress, so re-running continues where it stopped
"""
import argparse
import csv
import hashlib
import json
import os
import re
import sys
import time
from pathlib import Path
from urllib.parse import urlparse, parse_qs

import requests

from common import load_template, is_cfn_template, analyze_template

API = "https://api.github.com"
OUT = Path("corpus")
RAW = OUT / "raw"
META = OUT / "metadata.csv"
STATE = OUT / "state.json"

# What to search for (each keyword is a strong sign of a serverless/IaC template)
KEYWORDS = [
    '"AWS::Serverless::Function"',
    '"AWS::Serverless::Api"',
    '"AWS::Serverless::HttpApi"',
    '"AWS::ApiGateway::RestApi"',
    '"AWS::ApiGatewayV2::Api"',
    '"AWS::Lambda::Function"',
    '"AWS::IAM::Role" "AWSTemplateFormatVersion"',
]
EXTENSIONS = ["yaml", "yml", "json"]
# GitHub returns max 1000 results per query, so we split by file size (bytes)
SIZE_BANDS = ["500..1500", "1500..3000", "3000..6000", "6000..12000",
              "12000..25000", "25000..60000"]

META_FIELDS = ["file_id", "ext", "repo", "path", "commit", "license", "stars",
               "repo_pushed_at", "size_bytes", "sha256", "html_url",
               "near_dup_signature", "query"]

SECRET_RE = re.compile(r"AKIA[0-9A-Z]{16}|-----BEGIN (RSA |EC )?PRIVATE KEY-----")


class Github:
    def __init__(self, token):
        self.s = requests.Session()
        self.s.headers.update({
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        })

    def get(self, url, params=None, raw=False):
        """GET with automatic waiting when rate-limited."""
        for attempt in range(6):
            headers = {"Accept": "application/vnd.github.raw+json"} if raw else None
            r = self.s.get(url, params=params, headers=headers, timeout=60)
            if r.status_code in (403, 429):
                wait = r.headers.get("Retry-After")
                if wait:
                    wait = int(wait) + 2
                elif r.headers.get("X-RateLimit-Remaining") == "0":
                    wait = max(int(r.headers.get("X-RateLimit-Reset", 0)) - int(time.time()), 5) + 2
                else:
                    wait = 60
                print(f"  [rate limit] sleeping {wait}s ...", flush=True)
                time.sleep(wait)
                continue
            if r.status_code == 422:      # query not valid / too deep
                return None
            if r.status_code >= 500:
                time.sleep(10)
                continue
            r.raise_for_status()
            return r
        return None


def load_state():
    if STATE.exists():
        return json.loads(STATE.read_text())
    return {"done_queries": [], "seen_sha": [], "repo_cache": {}}


def save_state(st):
    STATE.write_text(json.dumps(st))


def signature(data):
    """Near-duplicate signature: the sorted multiset of resource TYPES.
    Many tutorial copies differ only in names, so they share this signature."""
    types = sorted(str(v.get("Type")) for v in data["Resources"].values() if isinstance(v, dict))
    return hashlib.md5("|".join(types).encode()).hexdigest()[:10]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true", help="small test run")
    ap.add_argument("--max-pages", type=int, default=10, help="pages per query (100 results each)")
    ap.add_argument("--min-stars", type=int, default=0)
    args = ap.parse_args()

    token = os.environ.get("GITHUB_TOKEN")
    if not token:
        sys.exit("ERROR: set GITHUB_TOKEN first (see README Step 3).")

    RAW.mkdir(parents=True, exist_ok=True)
    gh = Github(token)
    st = load_state()
    seen_sha = set(st["seen_sha"])
    repo_cache = st["repo_cache"]

    new_file = not META.exists()
    mf = open(META, "a", newline="", encoding="utf-8")
    w = csv.DictWriter(mf, fieldnames=META_FIELDS)
    if new_file:
        w.writeheader()

    keywords, exts, bands = KEYWORDS, EXTENSIONS, SIZE_BANDS
    max_pages = args.max_pages
    if args.quick:
        keywords, exts, bands, max_pages = KEYWORDS[:2], ["yaml"], SIZE_BANDS[1:3], 2

    stats = dict(downloaded=0, dup=0, fork=0, not_cfn=0, secret=0, small=0)

    for kw in keywords:
        for ext in exts:
            for band in bands:
                q = f"{kw} extension:{ext} size:{band}"
                if q in st["done_queries"]:
                    continue
                print(f"\nQUERY: {q}", flush=True)
                for page in range(1, max_pages + 1):
                    r = gh.get(f"{API}/search/code",
                               params={"q": q, "per_page": 100, "page": page})
                    time.sleep(6.5)   # code search allows ~10 requests/minute
                    if r is None:
                        break
                    items = r.json().get("items", [])
                    if not items:
                        break
                    for it in items:
                        repo = it["repository"]["full_name"]
                        if it["repository"].get("fork"):
                            stats["fork"] += 1
                            continue
                        if it["sha"] in seen_sha:
                            stats["dup"] += 1
                            continue
                        seen_sha.add(it["sha"])

                        # repo metadata (license, stars) - cached per repo
                        if repo not in repo_cache:
                            rr = gh.get(f"{API}/repos/{repo}")
                            if rr is None:
                                continue
                            j = rr.json()
                            repo_cache[repo] = {
                                "license": (j.get("license") or {}).get("spdx_id", "NONE"),
                                "stars": j.get("stargazers_count", 0),
                                "pushed_at": j.get("pushed_at", ""),
                                "fork": j.get("fork", False),
                            }
                        meta = repo_cache[repo]
                        if meta["fork"] or meta["stars"] < args.min_stars:
                            stats["fork"] += meta["fork"]
                            continue

                        # download the file content
                        fr = gh.get(it["url"], raw=True)
                        if fr is None:
                            continue
                        content = fr.content
                        if len(content) < 300:
                            stats["small"] += 1
                            continue
                        text = content.decode("utf-8", errors="ignore")
                        if SECRET_RE.search(text):
                            stats["secret"] += 1
                            continue
                        norm = re.sub(r"\s+", "", text)
                        sha256 = hashlib.sha256(norm.encode()).hexdigest()
                        file_id = sha256[:12]
                        if f"h_{sha256}" in seen_sha:
                            stats["dup"] += 1
                            continue
                        seen_sha.add(f"h_{sha256}")

                        fname = RAW / f"{file_id}.{ext}"
                        fname.write_bytes(content)
                        data = load_template(fname)
                        if not is_cfn_template(data):
                            fname.unlink()
                            stats["not_cfn"] += 1
                            continue

                        ref = parse_qs(urlparse(it["url"]).query).get("ref", [""])[0]
                        w.writerow({
                            "file_id": file_id, "ext": ext, "repo": repo,
                            "path": it["path"], "commit": ref,
                            "license": meta["license"], "stars": meta["stars"],
                            "repo_pushed_at": meta["pushed_at"],
                            "size_bytes": len(content), "sha256": sha256,
                            "html_url": it["html_url"],
                            "near_dup_signature": signature(data), "query": q,
                        })
                        mf.flush()
                        stats["downloaded"] += 1
                    print(f"  page {page}: total downloaded so far = {stats['downloaded']}", flush=True)
                    if len(items) < 100:
                        break
                st["done_queries"].append(q)
                st["seen_sha"] = list(seen_sha)
                st["repo_cache"] = repo_cache
                save_state(st)

    mf.close()
    print("\nDONE.", stats)
    print(f"Files are in {RAW}  |  metadata in {META}")


if __name__ == "__main__":
    main()
