"""
4_baseline.py - first ML experiments on your corpus, with an HONEST evaluation.

USAGE
    python 4_baseline.py

What it does
  1. Turns each template into a bag of structural tokens (resource types, property
     paths, IAM actions, auth settings ...) and TF-IDF vectorises them.
  2. Trains Logistic Regression and Random Forest to predict "misconfigured".
  3. Evaluates in two ways:
       (a) 5-fold CV where ALL files of one GitHub repo stay in the same fold
           (prevents the copy-paste leakage that inflates many papers)
       (b) train on everything EXCEPT the gold files and their repos, test on the
           human-labelled GOLD set (review/gold.csv) - this is your headline result.
  4. Prints how many gold misconfigurations the tools missed but the model found.

Output: results/baseline_results.csv
"""
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import precision_recall_fscore_support
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline

from common import load_template

OUT, REV, RES = Path("corpus"), Path("review"), Path("results")
RES.mkdir(exist_ok=True)

KEY_VALUES = {"Action", "Effect", "AuthorizationType", "AuthType", "Authorizer",
              "DefaultAuthorizer", "Principal", "Type", "Method", "ApiKeyRequired",
              "NotAction", "AllowOrigin", "AllowOrigins"}


def walk(node, prefix, depth, toks):
    if depth > 6:
        return
    if isinstance(node, dict):
        for k, v in node.items():
            k = str(k)
            path = f"{prefix}.{k}"
            toks.append("P:" + path)
            if k in KEY_VALUES and isinstance(v, (str, int, bool)):
                toks.append(f"V:{k}={str(v).lower()[:40]}")
            walk(v, path, depth + 1, toks)
    elif isinstance(node, list):
        for x in node:
            walk(x, prefix, depth + 1, toks)
    elif isinstance(node, str) and (":" in node and len(node) < 60 and " " not in node):
        toks.append("S:" + node.lower())       # e.g. iam:passrole, s3:*


def template_tokens(path):
    data = load_template(path)
    if not data:
        return ""
    toks = []
    for rid, r in (data.get("Resources") or {}).items():
        if not isinstance(r, dict):
            continue
        t = str(r.get("Type"))
        toks.append("T:" + t)
        walk(r.get("Properties") or {}, t, 0, toks)
    walk(data.get("Globals") or {}, "Globals", 0, toks)
    return " ".join(t.replace(" ", "_") for t in toks)


def models():
    vec = lambda: TfidfVectorizer(tokenizer=str.split, lowercase=False, token_pattern=None,
                                  min_df=3, sublinear_tf=True)
    return {
        "LogReg": lambda: make_pipeline(vec(), LogisticRegression(max_iter=2000, class_weight="balanced")),
        "RandomForest": lambda: make_pipeline(vec(), RandomForestClassifier(
            n_estimators=300, class_weight="balanced", n_jobs=-1, random_state=0)),
    }


def prf(y, p):
    pr, rc, f1, _ = precision_recall_fscore_support(y, p, average="binary", zero_division=0)
    return round(pr, 3), round(rc, 3), round(f1, 3)


def main():
    lab = pd.read_csv(OUT / "labels.csv")
    meta = pd.read_csv(OUT / "metadata.csv")[["file_id", "ext"]]
    lab = lab.merge(meta, on="file_id")
    print("Reading templates ...")
    lab["doc"] = [template_tokens(OUT / "raw" / f"{a}.{b}") for a, b in zip(lab.file_id, lab.ext)]
    lab = lab[lab.doc.str.len() > 0].reset_index(drop=True)

    # training label = what the tools say (consensus if Checkov is available)
    if lab.agreement.eq("custom_only").all():
        lab["y"] = lab.label_custom
        train_mask = np.ones(len(lab), bool)
    else:
        train_mask = lab.agreement.isin(["agree_pos", "agree_neg"]).values
        lab["y"] = lab.label_custom
    print(f"Files: {len(lab)} | usable for training: {train_mask.sum()} | "
          f"positive rate: {lab.y[train_mask].mean():.1%}")
    if lab.y[train_mask].sum() < 20:
        print("WARNING: very few positive examples - collect more data before trusting results.")

    rows = []

    # ---- (a) repo-grouped cross-validation on tool labels ----
    d = lab[train_mask].reset_index(drop=True)
    gkf = GroupKFold(n_splits=5)
    for name, mk in models().items():
        pred = np.zeros(len(d), int)
        for tr, te in gkf.split(d.doc, d.y, groups=d.repo):
            m = mk().fit(d.doc[tr], d.y[tr])
            pred[te] = m.predict(d.doc[te])
        p, r, f = prf(d.y, pred)
        rows.append({"setting": "repo-grouped CV (tool labels)", "model": name,
                     "precision": p, "recall": r, "f1": f, "n": len(d)})
        print(f"[CV ] {name:13s} P={p} R={r} F1={f}")

    # ---- (b) gold evaluation ----
    gpath = REV / "gold.csv"
    if gpath.exists():
        gold = pd.read_csv(gpath)
        g = lab.merge(gold[["file_id", "gold"]], on="file_id")
        gold_repos = set(g.repo)
        tr = lab[train_mask & ~lab.file_id.isin(g.file_id) & ~lab.repo.isin(gold_repos)]
        print(f"\nGold eval: train={len(tr)} files (gold files and their repos removed), test={len(g)}")
        # tools vs gold
        for name, col in (("custom rules", "label_custom"), ("checkov", "label_checkov")):
            gg = g.dropna(subset=[col])
            if len(gg):
                p, r, f = prf(gg.gold, gg[col].astype(int))
                rows.append({"setting": "GOLD", "model": "tool: " + name, "precision": p,
                             "recall": r, "f1": f, "n": len(gg)})
                print(f"[GOLD] tool {name:13s} P={p} R={r} F1={f}")
        for name, mk in models().items():
            m = mk().fit(tr.doc, tr.y)
            pred = m.predict(g.doc)
            p, r, f = prf(g.gold, pred)
            rows.append({"setting": "GOLD", "model": name, "precision": p, "recall": r,
                         "f1": f, "n": len(g)})
            print(f"[GOLD] {name:13s} P={p} R={r} F1={f}")
            if name == "RandomForest":
                tools_neg = (g.label_custom == 0) & (g.label_checkov.fillna(0).astype(int) == 0)
                missed = g[(g.gold == 1) & tools_neg]
                found = int((pred[missed.index] == 1).sum()) if len(missed) else 0
                print(f"\nGold misconfigs that BOTH tools missed: {len(missed)}; "
                      f"the model caught {found} of them  <- 'novel findings' for your paper")
    else:
        print("\n(no review/gold.csv yet - do the manual review step to get the headline result)")

    pd.DataFrame(rows).to_csv(RES / "baseline_results.csv", index=False)
    print(f"\nSaved {RES/'baseline_results.csv'}")


if __name__ == "__main__":
    main()
