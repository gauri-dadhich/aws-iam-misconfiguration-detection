# IAM + API Misconfiguration Corpus Toolkit

Builds a **real-world, human-verified dataset** of serverless (AWS SAM / CloudFormation)
templates, labeled for **IAM** and **API** misconfigurations, including **cross-resource**
ones (e.g. a public API with no authorizer that triggers a function with admin rights).

| Script | What it does | Time |
|---|---|---|
| `0_selftest.py` | checks your setup works | 5 sec |
| `1_collect.py` | downloads templates from GitHub | 1–3 h (runs by itself) |
| `2_label.py` | labels them with Checkov + our own IAM/API rules | 10–60 min |
| `3_review.py` | manual review, Cohen's kappa, gold test set | your effort (see Step 8) |
| `4_baseline.py` | ML models + honest evaluation | 1–5 min |

> Tested offline: the parser, rule engine, labeling merge, review/kappa/gold, and ML script.
> **Not tested** (needs internet): the live GitHub download and the Checkov run. If either
> errors, copy the error message and send it to me.

---

## Step 1 – Install Python
Download Python 3.10 or newer from python.org. **On Windows tick "Add Python to PATH"** in the installer.
Check: open a terminal (Windows: PowerShell) and type `python --version`.

## Step 2 – Set up the folder
Unzip this toolkit, open a terminal **inside the folder**, then:

```
python -m venv venv
# Windows:      venv\Scripts\activate
# Mac/Linux:    source venv/bin/activate
pip install -r requirements.txt
```
(Checkov is large; installing can take 5–10 minutes.)

## Step 3 – Get a GitHub token (free, 2 minutes)
1. Log in to github.com → click your picture → **Settings** → **Developer settings** →
   **Personal access tokens** → **Tokens (classic)** → **Generate new token (classic)**.
2. Name it `corpus`, set expiry 30 days, **tick no scopes** (public data only), generate.
3. Copy the token (starts with `ghp_`). Put it in the terminal (keep the terminal open):
   - Windows PowerShell: `$env:GITHUB_TOKEN="ghp_yourtokenhere"`
   - Mac/Linux: `export GITHUB_TOKEN="ghp_yourtokenhere"`

## Step 4 – Self-test
`python 0_selftest.py` → you should see three PASS lines.

## Step 5 – Quick test download (about 10 minutes)
`python 1_collect.py --quick`
Then open `corpus/metadata.csv` (Excel is fine). You should see some tens/hundreds of rows
and files in `corpus/raw/`. If you get a 401 error, the token is wrong. If it finds 0 results,
tell me – the `size:` search filter may need removing.

## Step 6 – Full download (leave running)
`python 1_collect.py`
- Takes 1–3 hours. Keep the laptop plugged in and **set sleep to "never"**.
- You can stop with `Ctrl+C` and run the same command again – it resumes where it stopped.
- Target: **2,000+ files** in `corpus/raw/`. If you get fewer, run again on another day
  with `--max-pages 10` (default) or add keywords in `KEYWORDS` at the top of the script.
- It already skips forks, tiny files, duplicates, unparseable files and files containing secrets.

## Step 7 – Label automatically
First a fast check without Checkov: `python 2_label.py --skip-checkov`
Then the real run: `python 2_label.py`
It prints a **summary** (how many files flagged, per rule counts) – these numbers go into your
dataset table in the paper. Output: `corpus/labels.csv`.
The `agreement` column shows `agree_pos / agree_neg / disagree` between Checkov and our rules.
The **disagree** files are your "hard cases" – discuss them in the paper.

## Step 8 – Manual review (this is what makes the labels trustworthy)
`python 3_review.py sample --n 200`
This creates `review/annotator_A.csv` and `annotator_B.csv` (open in Excel).
Two people (you + a friend/junior/guide's student) each fill in, **independently**, for every row:
open the file in `open_this_file` with Notepad/VS Code, then write
`is_misconfigured` = 1 or 0, `category` = IAM / API / BOTH / NONE.

**Annotation guideline – write this in your paper too. Mark 1 if:**
- an Allow statement gives `*` actions, or service-wide `service:*`, on `*` resources (beyond logging/tracing),
- it allows privilege-escalation actions (`iam:PassRole`, `iam:Put*Policy`, `lambda:UpdateFunctionCode`, ...) without tight scoping,
- a role can be assumed by anyone (`Principal: *`) with no condition,
- AdministratorAccess / PowerUserAccess is attached,
- an API endpoint or Lambda URL is publicly callable with no authorizer **and** it reaches sensitive data or privileges (a public health-check or login route is acceptable → 0),
- CORS allows any origin on an authenticated/sensitive API.

Time: about 2 minutes per file → 200 files ≈ 6–7 hours each. If too much, use `--n 120`.
No second person at all? Do it alone, state this as a limitation, and report agreement between you and the tools instead of kappa.

When both finish:
```
python 3_review.py kappa      # prints Cohen's kappa, creates disagreements.csv
```
Open `review/disagreements.csv`, discuss each row, write 1 or 0 in `final_label`, save, then:
```
python 3_review.py gold       # creates review/gold.csv + precision/recall of the tools vs humans
```

## Step 9 – ML experiments
`python 4_baseline.py`
Look at the `[GOLD]` lines – they are your headline results. Results are saved in `results/baseline_results.csv`.

---

## How to read the results (important)
- The `[CV]` numbers (training labels come from the tools) will probably look very high, because the model
  is imitating rules. **Do not present them as the main result.**
- The `[GOLD]` numbers (human labels, unseen repositories) are the honest ones. Report them.
- "Gold misconfigs both tools missed but the model caught" is your **novel-findings** number.
  Even a small count (5–10) is a real contribution.
- If the model does *not* beat the tools on gold, that is still publishable: you show the tools'
  precision/recall against humans for the first time on this topic, and where ML helps or does not.

## What to put in the paper
1. **Contribution 1** – a benchmark of N real templates (table: sources, licenses, size, % flagged per category).
2. **Contribution 2** – cross-resource rules (IAM × API) and how many real templates contain them
   (`CROSS_PUBLIC_PRIVILEGED_FUNCTION` count in step 7).
3. **Contribution 3** – evaluation: Checkov vs custom rules vs ML, on gold; repo-grouped splits; kappa.
4. **Threats to validity** (write openly): public GitHub ≠ company production; labels partly tool-derived
   (mitigated by human gold set); our rules approximate AWS policy evaluation (see Shevrin & Margalit for the
   formal version); plain CloudFormation Lambda↔API links are not resolved, only SAM events.
5. Release only file hashes + the scripts if licenses are restrictive (the metadata stores each license).

## Troubleshooting
| Problem | Fix |
|---|---|
| `GITHUB_TOKEN` error | You opened a new terminal – set the token again (Step 3) |
| `checkov` not found | Activate the venv again (Step 2) |
| Checkov batch timed out | Fine, it is skipped; rerun with fewer files or raise `timeout` in `run_checkov` |
| 0 results from search | Remove `size:` bands in `SIZE_BANDS` or tell me the error |
| Very few positives | Add vulnerable-by-design repos (CloudGoat, serverless-goat) and rerun Step 6 |
