"""0_selftest.py - checks that your installation works. Run this first:  python 0_selftest.py"""
from pathlib import Path
from common import load_template, is_cfn_template, analyze_template

EXPECTED = {
    "bad_cross.yaml": {"CROSS_PUBLIC_PRIVILEGED_FUNCTION", "API_NO_AUTHORIZER"},
    "good.yaml": set(),
    "role_bad.yaml": {"IAM_MANAGED_ADMIN", "IAM_TRUST_WILDCARD_PRINCIPAL", "API_FUNCTION_URL_NO_AUTH"},
}
ok = True
for name, must in EXPECTED.items():
    d = load_template(Path("test_samples") / name)
    got = set(analyze_template(d)["findings"])
    good = must <= got and (bool(must) or not got)
    ok &= good
    print(("PASS" if good else "FAIL"), name, sorted(got))
print("\nAll good - you can continue to Step 5." if ok else "\nSomething is wrong - check installation.")
